package com.jp.voiceassistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * A small silver orb for the wake panel: rotating rings, a cloud of particles and a bright core.
 * Same idea as the big orb in the app, drawn natively so it stays light.
 * mode: awake | hearing | thinking | speaking
 */
class OrbView(ctx: Context) : View(ctx) {

    @Volatile var mode: String = "awake"
    @Volatile var level: Float = 0f

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val corePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val oval = RectF()

    private val n = 64
    private val px = FloatArray(n)
    private val py = FloatArray(n)
    private val pz = FloatArray(n)
    private val rings = floatArrayOf(0f, 0.9f, 1.8f, 2.7f)

    private var spin = 0f
    private var last = 0L
    private var glow: RadialGradient? = null
    private var glowSize = 0
    private var lv = 0f

    init {
        val rnd = java.util.Random(7)
        for (i in 0 until n) {
            var x: Double
            var y: Double
            var z: Double
            var d: Double
            do {
                x = rnd.nextDouble() * 2 - 1
                y = rnd.nextDouble() * 2 - 1
                z = rnd.nextDouble() * 2 - 1
                d = x * x + y * y + z * z
            } while (d > 1.0 || d < 0.01)
            val s = sqrt(d)
            px[i] = (x / s).toFloat()
            py[i] = (y / s).toFloat()
            pz[i] = (z / s).toFloat()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 0.016f else ((now - last) / 1000f).coerceAtMost(0.05f)
        last = now
        val t = now / 1000f

        val speed = when (mode) {
            "hearing" -> 2.2f
            "thinking" -> 3f
            "speaking" -> 1.6f
            else -> 1f
        }
        spin += dt * 0.9f * speed
        lv += (level - lv) * minOf(1f, dt * 12f)

        val cx = width / 2f
        val cy = height / 2f
        val base = min(width, height) * 0.34f
        val r = base * (1f + lv * 0.18f + (if (mode == "speaking") 0.04f * sin(t * 18f) else 0f))
        val bright = when (mode) {
            "hearing" -> 1f
            "speaking" -> 0.95f
            "thinking" -> 0.9f
            else -> 0.8f
        }

        // glow
        val size = min(width, height)
        if (glow == null || glowSize != size) {
            glow = RadialGradient(
                0f, 0f, size * 0.5f,
                intArrayOf(Color.argb(110, 205, 215, 235), Color.argb(34, 150, 165, 195), Color.argb(0, 120, 135, 165)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
            glowSize = size
        }
        canvas.save()
        canvas.translate(cx, cy)
        glowPaint.shader = glow
        glowPaint.alpha = (255 * bright).toInt().coerceAtMost(255)
        canvas.drawCircle(0f, 0f, size * 0.5f, glowPaint)

        // rings: great circles that tumble, so they read as a sphere
        ringPaint.strokeWidth = maxOf(1f, base / 28f)
        for (k in rings.indices) {
            val a = spin * (0.5f + k * 0.22f) + rings[k]
            val squash = abs(cos(a)).coerceAtLeast(0.12f)
            canvas.save()
            canvas.rotate(k * 47f + spin * 12f)
            oval.set(-r, -r * squash, r, r * squash)
            ringPaint.color = Color.argb((200 * bright * (0.35f + 0.65f * squash)).toInt(), 222, 229, 242)
            canvas.drawOval(oval, ringPaint)
            canvas.restore()
        }

        // particles
        val cs = cos(spin)
        val sn = sin(spin)
        val dotR = maxOf(1.1f, base / 22f)
        for (i in 0 until n) {
            val x1 = px[i] * cs + pz[i] * sn
            val z1 = -px[i] * sn + pz[i] * cs
            val depth = 0.35f + 0.65f * (z1 + 1f) / 2f
            val tw = 0.55f + 0.45f * sin(t * (2f + i % 5) + i)
            dotPaint.color = Color.argb((235 * bright * depth * tw).toInt().coerceIn(0, 255), 214, 222, 238)
            canvas.drawCircle(x1 * r * 1.02f, py[i] * r * 1.02f, dotR * (0.6f + 0.5f * depth), dotPaint)
        }

        // core
        val cr = r * 0.2f * (1f + 0.07f * sin(t * 2.2f) + lv * 0.4f)
        corePaint.shader = RadialGradient(
            0f, 0f, cr * 2.4f,
            intArrayOf(Color.argb(255, 246, 248, 253), Color.argb(130, 200, 210, 230), Color.argb(0, 150, 165, 195)),
            floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP
        )
        canvas.drawCircle(0f, 0f, cr * 2.4f, corePaint)
        ringPaint.strokeWidth = maxOf(1f, base / 34f)
        ringPaint.color = Color.argb((255 * bright).toInt(), 235, 240, 250)
        canvas.drawCircle(0f, 0f, cr, ringPaint)

        canvas.restore()
        postInvalidateOnAnimation()
    }
}
