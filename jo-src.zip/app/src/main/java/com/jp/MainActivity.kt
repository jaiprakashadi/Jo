package com.jp.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.widget.Toast
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject

/**
 * Jo's screen is a small web page (assets/ui/index.html) shown in a WebView.
 * The page draws the orb and the cards; this class feeds it state and
 * carries out what the buttons ask for.
 */
class MainActivity : Activity() {

    private lateinit var prefs: JoPrefs
    private lateinit var web: WebView
    private var agent: Agent? = null
    private val lines = ArrayList<String>()
    private val handler = Handler(Looper.getMainLooper())
    private var pageReady = false
    private var visible = false
    private var tickCount = 0

    private val ticker = object : Runnable {
        override fun run() {
            if (!visible) return
            if (pageReady) {
                web.evaluateJavascript(
                    "window.joTick&&window.joTick('" + VoiceService.state + "'," + VoiceService.level + ")", null
                )
                tickCount++
                if (tickCount % 15 == 0) pushState()
            }
            handler.postDelayed(this, 70)
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun call(name: String, arg: String) {
            runOnUiThread { onCall(name, arg) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashLog.install(this)
        prefs = JoPrefs(this)
        agent = Agent(this, { log("Jo: $it") }, { log(it) })

        val bg = Color.parseColor("#07080A")
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        web = WebView(this)
        web.setBackgroundColor(bg)
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false // bundled pages (android_asset) still load
            allowContentAccess = false
            allowFileAccessFromFileURLs = false
            allowUniversalAccessFromFileURLs = false
            javaScriptCanOpenWindowsAutomatically = false
            cacheMode = WebSettings.LOAD_NO_CACHE
            textZoom = 100
        }
        web.addJavascriptInterface(Bridge(), "Android")
        web.webViewClient = object : WebViewClient() {
            // Jo's page never navigates anywhere else, so nothing outside can reach the bridge.
            override fun shouldOverrideUrlLoading(view: WebView?, request: android.webkit.WebResourceRequest?): Boolean = true

            override fun onPageFinished(view: WebView?, url: String?) {
                pageReady = true
                pushState()
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/ui/index.html")

        CrashLog.read(this)?.let { log("LAST CRASH (send this to Claude):\n" + it.take(1800)) }
    }

    override fun onResume() {
        super.onResume()
        visible = true
        for (m in VoiceService.history().takeLast(60)) {
            if (!lines.contains(m)) lines.add(0, m)
        }
        VoiceService.onLog = { log(it) }
        pushState()
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    override fun onPause() {
        visible = false
        VoiceService.onLog = null
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    override fun onDestroy() {
        VoiceService.onLog = null
        handler.removeCallbacksAndMessages(null)
        web.removeJavascriptInterface("Android")
        web.destroy()
        super.onDestroy()
    }

    // ------------------------------------------------------------ requests from the page

    private fun onCall(name: String, arg: String) {
        when (name) {
            "ready" -> pushState()
            "perms" -> askPermissions()
            "acc" -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            "overlay" -> startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            "enroll" -> enroll()
            "toggle" -> toggleService()
            "owner" -> { prefs.ownerOnly = !prefs.ownerOnly; pushState() }
            "auto" -> { prefs.autoSend = !prefs.autoSend; pushState() }
            "strict" -> {
                val v = arg.toIntOrNull() ?: 1
                prefs.strictness = v.coerceIn(0, 2) - 1
                pushState()
            }
            "speak" -> { prefs.speak = !prefs.speak; pushState() }
            "screen" -> {
                prefs.screenAgent = !prefs.screenAgent
                if (prefs.screenAgent && SendAccessibilityService.instance == null) {
                    log("Also turn on Jo in Accessibility, or Jo cannot see the screen.")
                }
                pushState()
            }
            "steps" -> {
                val n = arg.toIntOrNull()
                if (n != null) prefs.stepCap = n
                pushState()
            }
            "battery" -> askBattery()
            "copylog" -> copyLog()
            "provider" -> {
                prefs.provider = Providers.byId(arg).id
                prefs.model = ""
                pushState()
            }
            "model" -> { prefs.model = arg; pushState() }
            "curl" -> {
                if (arg.isEmpty() || Providers.isSafeUrl(arg)) {
                    prefs.customUrl = arg
                    log("Address saved.")
                } else {
                    log("Error: the address must start with https://")
                }
                pushState()
            }
            "cap" -> {
                val n = arg.toIntOrNull()
                if (n != null) prefs.dailyCap = n
                pushState()
            }
            "getkey" -> {
                val url = Providers.byId(prefs.provider).keyUrl
                if (url.startsWith("https://")) {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                    } catch (e: Exception) {
                        log("Could not open the browser. Search for the provider's API keys page.")
                    }
                } else {
                    log("Custom: get the key from your provider's website.")
                }
            }
            "test" -> testBrain()
            "key" -> {
                prefs.apiKey = arg.trim()
                log(
                    if (prefs.apiKey.isEmpty()) "Key cleared."
                    else "Key saved (encrypted). Tap Test to check it."
                )
            }
            "run" -> if (arg.isNotBlank()) {
                log("You (typed): $arg")
                agent?.handle(arg)
            }
        }
    }

    private fun askBattery() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isIgnoringBatteryOptimizations(packageName)) {
            log("Jo is already allowed to run in the background.")
            return
        }
        try {
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e2: Exception) {
                log("Could not open the battery setting.")
            }
        }
    }

    private fun copyLog() {
        val sb = StringBuilder("Jo log\n")
        for (l in lines.reversed()) sb.append(l).append('\n')
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Jo log", sb.toString()))
        Toast.makeText(this, "Log copied", Toast.LENGTH_SHORT).show()
    }

    private fun testBrain() {
        if (prefs.apiKey.isBlank()) {
            log("Error: no key saved yet.")
            return
        }
        val gate = Brain.gate(prefs)
        if (gate != null) {
            log("Error: $gate")
            return
        }
        log("Testing the AI...")
        Thread {
            val r = Brain.ask(prefs, emptyList(), "Say hello in five words.")
            runOnUiThread {
                if (r.error != null) log("Error: AI test failed. ${r.error}")
                else log("AI works. It said: ${r.say.ifBlank { "(nothing)" }}")
            }
        }.start()
    }

    private fun granted(p: String): Boolean =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun askPermissions() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        pushState()
    }

    private fun toggleService() {
        if (VoiceService.isRunning) {
            stopService(Intent(this, VoiceService::class.java))
        } else {
            if (!granted(Manifest.permission.RECORD_AUDIO)) {
                log("Microphone permission missing. Tap the first card under Set up.")
                askPermissions()
                return
            }
            try {
                startForegroundService(Intent(this, VoiceService::class.java))
            } catch (e: Exception) {
                log("Could not start: ${e.message}")
            }
        }
        handler.postDelayed({ pushState() }, 500)
    }

    private fun enroll() {
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            log("Microphone permission missing. Tap the first card under Set up.")
            askPermissions()
            return
        }
        try {
            startForegroundService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_ENROLL))
            log("Learning your voice. Wait for Jo to speak, then read each sentence out loud.")
        } catch (e: Exception) {
            log("Could not start: ${e.message}")
        }
        handler.postDelayed({ pushState() }, 500)
    }

    // ------------------------------------------------------------ state for the page

    private fun pushState() {
        if (!pageReady) return
        val o = JSONObject()
        o.put("running", VoiceService.isRunning)
        o.put("enrolled", prefs.ownerVector != null)
        o.put("mic", granted(Manifest.permission.RECORD_AUDIO))
        o.put("contacts", granted(Manifest.permission.READ_CONTACTS))
        o.put("calls", granted(Manifest.permission.CALL_PHONE))
        o.put("acc", SendAccessibilityService.instance != null)
        o.put("overlay", Settings.canDrawOverlays(this))
        o.put("owner", prefs.ownerOnly)
        o.put("auto", prefs.autoSend)
        o.put("strict", prefs.strictness + 1)
        o.put("hasKey", prefs.hasKey)
        o.put("speak", prefs.speak)
        o.put("screen", prefs.screenAgent)
        o.put("stepCap", prefs.stepCap)
        o.put("steps", prefs.usedSteps)
        o.put("battery", (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName))
        o.put("provider", prefs.provider)
        o.put("model", prefs.model)
        o.put("customUrl", prefs.customUrl)
        o.put("cap", prefs.dailyCap)
        o.put("used", prefs.usedToday)
        val pa = JSONArray()
        for (p in Providers.all) {
            pa.put(JSONObject().put("id", p.id).put("name", p.name).put("model", p.model).put("note", p.note))
        }
        o.put("providers", pa)
        val arr = JSONArray()
        for (l in lines) arr.put(l)
        o.put("log", arr)
        val js = o.toString().replace(" ", " ").replace(" ", " ")
        web.evaluateJavascript("window.joState&&window.joState($js)", null)
    }

    private fun log(msg: String) {
        runOnUiThread {
            lines.add(0, msg)
            while (lines.size > 80) lines.removeAt(lines.size - 1)
            pushState()
        }
    }
}
