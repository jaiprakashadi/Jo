package com.jp.voiceassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.AssetManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.text.TextUtils
import android.view.View
import android.media.AudioManager
import android.media.ToneGenerator
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import android.view.WindowManager
import org.json.JSONObject
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.SpeakerModel
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.sqrt

/** Copies the offline voice models out of the APK the first time Jo starts. */
object Models {
    fun prepare(ctx: Context, log: (String) -> Unit): Pair<String, String> {
        val base = File(ctx.filesDir, "models")
        val stt = File(base, "stt")
        val spk = File(base, "spk")
        val marker = File(base, "ready_v1")
        if (!marker.exists()) {
            log("First start: unpacking voice models (about 30 seconds)...")
            base.deleteRecursively()
            base.mkdirs()
            copyAssets(ctx.assets, "stt", stt)
            copyAssets(ctx.assets, "spk", spk)
            marker.writeText("ok")
            log("Voice models ready.")
        }
        return Pair(stt.absolutePath, spk.absolutePath)
    }

    private fun copyAssets(am: AssetManager, path: String, dest: File) {
        val children = am.list(path) ?: emptyArray()
        if (children.isEmpty()) {
            dest.parentFile?.mkdirs()
            try {
                am.open(path).use { input ->
                    FileOutputStream(dest).use { out -> input.copyTo(out) }
                }
            } catch (e: java.io.IOException) {
                dest.mkdirs() // it was an empty folder
            }
        } else {
            dest.mkdirs()
            for (name in children) copyAssets(am, "$path/$name", File(dest, name))
        }
    }
}

/**
 * Jo's ears and mouth. Runs in the background:
 * microphone -> speech detection -> offline speech-to-text + voiceprint -> Agent.
 */
class VoiceService : Service() {

    companion object {
        @Volatile var isRunning = false
        @Volatile var onLog: ((String) -> Unit)? = null

        /** off | loading | idle | hearing | thinking | speaking  (drives the orb in the app) */
        @Volatile var state = "off"

        /** 0..1 microphone loudness, for the orb */
        @Volatile var level = 0f
        const val ACTION_ENROLL = "com.jp.voiceassistant.ENROLL"
        const val ACTION_STOP = "com.jp.voiceassistant.STOP"
        const val ACTION_STOP_TASK = "com.jp.voiceassistant.STOP_TASK"

        private val buffer = ArrayList<String>()
        private const val CHANNEL = "jo_listening"
        private const val RATE = 16000
        private const val MIN_VERIFY_FRAMES = 50
        private const val MIN_ENROLL_FRAMES = 45
        private val IDLE_COLOR = Color.parseColor("#38BDF8")
        private val HEAR_COLOR = Color.parseColor("#FBBF24")
        private val SPEAK_COLOR = Color.parseColor("#34D399")

        private val WAKE = Regex("^(?:(?:hey|hi|hello|ok|okay)\\s+)?(?:jo|joe|joey|joy|jojo|zoe)\\b\\s*(.*)$")
        private val WAKE_LOOSE = Regex("(?:^|\\s)(?:jo|joe|joey|joy|jojo|zoe)\\b")
        private val WAKE_STRIP = Regex("^(?:(?:hey|hi|hello|ok|okay)\\s+)?\\w+\\s*")
        private val WAKE_GRAMMAR = JSONArray(
            listOf(
                "hey jo", "hello jo", "hi jo", "ok jo", "okay jo",
                "hey joe", "hello joe", "hi joe", "ok joe", "okay joe",
                "jo", "joe", "[unk]"
            )
        ).toString()

        private val ENROLL_PHRASES = listOf(
            "Hey Jo, this is my voice and only I can give you commands",
            "Jo, open WhatsApp and send a message to my friend",
            "The quick brown fox jumps over the lazy dog near the river",
            "Jo, call my mother and tell her I will be late today",
            "Please remember my voice so that nobody else can control my phone"
        )

        fun log(msg: String) {
            synchronized(buffer) {
                buffer.add(msg)
                while (buffer.size > 150) buffer.removeAt(0)
            }
            onLog?.invoke(msg)
        }

        fun history(): List<String> = synchronized(buffer) { ArrayList(buffer) }
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var prefs: JoPrefs
    private var agent: Agent? = null

    @Volatile private var running = false
    @Volatile private var ready = false
    private var worker: Thread? = null

    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var speakingUntil = 0L
    @Volatile private var sessionUntil = 0L

    @Volatile private var enrolling = false
    private val enrollVecs = ArrayList<DoubleArray>()

    private var panel: View? = null
    private var orbView: OrbView? = null
    private var panelText: TextView? = null
    @Volatile private var sleepAfterSpeech = false

    // ------------------------------------------------------------ lifecycle

    override fun onCreate() {
        super.onCreate()
        CrashLog.install(this)
        prefs = JoPrefs(this)
        agent = Agent(applicationContext, { speak(it) }, { log(it) }, { stopSelf() }, { sleepAfterSpeech = true; sessionUntil = 0L })

        tts = TextToSpeech(this) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                if (t.setLanguage(Locale("en", "IN")) < 0) t.setLanguage(Locale.US)
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        speakingUntil = SystemClock.elapsedRealtime() + 60_000
                        setDot(SPEAK_COLOR)
                    }

                    override fun onDone(utteranceId: String?) {
                        val t0 = SystemClock.elapsedRealtime()
                        speakingUntil = t0 + 500
                        if (sleepAfterSpeech) {
                            sleepAfterSpeech = false
                            sessionUntil = 0L
                        } else if (sessionUntil > 0L) {
                            sessionUntil = maxOf(sessionUntil, t0 + 7_000)
                        }
                        setDot(IDLE_COLOR)
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        speakingUntil = SystemClock.elapsedRealtime() + 300
                        setDot(IDLE_COLOR)
                    }
                })
                ttsReady = true
            } else {
                log("Jo cannot speak (text-to-speech not available), but will still listen.")
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_STOP_TASK) {
            agent?.stopTask()
            if (running) return START_STICKY
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Jo is listening", NotificationManager.IMPORTANCE_LOW)
        )
        val stopIntent = PendingIntent.getService(
            this, 11,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopTaskIntent = PendingIntent.getService(
            this, 13,
            Intent(this, VoiceService::class.java).setAction(ACTION_STOP_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val openIntent = PendingIntent.getActivity(
            this, 12,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Jo is on standby")
            .setContentText("Resting. Say \"Hey Jo\" to wake me")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openIntent)
            .addAction(Notification.Action.Builder(null, "Stop task", stopTaskIntent).build())
            .addAction(Notification.Action.Builder(null, "Turn off", stopIntent).build())
            .build()

        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(1, notification)
            }
        } catch (e: Exception) {
            log("Cannot start listening: ${e.message}")
            stopSelf()
            return START_NOT_STICKY
        }

        if (intent?.action == ACTION_ENROLL) beginEnroll()

        if (!running) {
            running = true
            isRunning = true
            state = "loading"
            main.post(ticker)
            worker = Thread { runLoop() }.also {
                it.name = "jo-audio"
                it.start()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        isRunning = false
        state = "off"
        level = 0f
        try {
            worker?.join(1500)
        } catch (ignored: InterruptedException) {
        }
        tts?.stop()
        tts?.shutdown()
        tts = null
        main.removeCallbacks(ticker)
        hidePanel()
        log("Jo stopped listening.")
        super.onDestroy()
    }

    // ------------------------------------------------------------ wake panel (appears only while Jo is awake)

    private fun awakeNow(): Boolean =
        enrolling || SystemClock.elapsedRealtime() < sessionUntil || agent?.waiting() == true

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            if (ready) {
                val aw = awakeNow()
                // While Jo operates another app its panel stays hidden, so it can never cover a button.
                val show = aw && agent?.screenBusy() != true
                if (show && panel == null) showPanel()
                if (!show && panel != null) hidePanel()
                if (state == "idle" || state == "awake") state = if (aw) "awake" else "idle"
                orbView?.mode = when (state) {
                    "hearing", "speaking", "thinking" -> state
                    else -> "awake"
                }
                orbView?.level = level
            }
            main.postDelayed(this, 100)
        }
    }

    private fun showPanel() {
        if (panel != null || !Settings.canDrawOverlays(this)) return
        try {
            val d = resources.displayMetrics.density
            fun dp(v: Int) = (v * d).toInt()
            val orb = OrbView(this)
            val tv = TextView(this).apply {
                text = "Listening..."
                setTextColor(Color.parseColor("#ECEAE6"))
                textSize = 15f
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(22), dp(8))
                background = GradientDrawable().apply {
                    cornerRadius = dp(34).toFloat()
                    setColor(Color.argb(220, 12, 13, 16))
                    setStroke(dp(1), Color.argb(60, 255, 255, 255))
                }
                addView(orb, LinearLayout.LayoutParams(dp(68), dp(68)))
                addView(tv, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    leftMargin = dp(8)
                })
            }
            val lp = WindowManager.LayoutParams(
                resources.displayMetrics.widthPixels - dp(32),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            )
            // Tap the panel to send Jo back to rest.
            box.setOnClickListener {
                sessionUntil = 0L
                sleepAfterSpeech = false
                tts?.stop()
                speakingUntil = 0L
            }
            lp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            lp.y = dp(64)
            if (Build.VERSION.SDK_INT >= 31) {
                lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
                lp.blurBehindRadius = 40
            }
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(box, lp)
            panel = box
            orbView = orb
            panelText = tv
        } catch (e: Exception) {
            log("Wake panel not shown: ${e.message}")
        }
    }

    private fun hidePanel() {
        val v = panel ?: return
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (ignored: Exception) {
        }
        panel = null
        orbView = null
        panelText = null
    }

    private fun panelSay(text: String) {
        main.post { panelText?.text = text }
    }

    private fun beep() {
        try {
            speakingUntil = SystemClock.elapsedRealtime() + 350
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_ACK, 150)
            main.postDelayed({
                try { tg.release() } catch (ignored: Exception) {}
            }, 600)
        } catch (ignored: Exception) {
        }
    }

    private fun setDot(color: Int) {
        if (running && ready) {
            state = when (color) {
                SPEAK_COLOR -> "speaking"
                HEAR_COLOR -> "hearing"
                else -> if (awakeNow()) "awake" else "idle"
            }
            if (color == HEAR_COLOR) panelSay("Listening...")
        }
    }

    // ------------------------------------------------------------ speaking

    fun speak(text: String) {
        log("Jo: $text")
        // Keep the conversation open a bit after Jo talks.
        sessionUntil = SystemClock.elapsedRealtime() + 8_000L + text.length * 70L
        panelSay(text)
        if (!prefs.speak) {
            // Silent mode: nothing will say "done", so settle the session here.
            if (sleepAfterSpeech) {
                sleepAfterSpeech = false
                main.postDelayed({ sessionUntil = 0L }, 2500)
            }
            return
        }
        val t = tts
        if (!ttsReady || t == null) return
        speakingUntil = SystemClock.elapsedRealtime() + 1500L + text.length * 80L
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jo-" + System.nanoTime())
    }

    // ------------------------------------------------------------ main audio loop

    private fun rms(b: ShortArray, n: Int): Double {
        var sum = 0.0
        for (i in 0 until n) {
            val v = b[i].toDouble()
            sum += v * v
        }
        return sqrt(sum / n)
    }

    private fun runLoop() {
        try {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
        } catch (ignored: Exception) {
        }
        var rec: AudioRecord? = null
        var model: Model? = null
        var spk: SpeakerModel? = null
        var recognizer: Recognizer? = null
        var wakeRec: Recognizer? = null
        try {
            val paths = Models.prepare(this) { log(it) }
            if (!running) return
            log("Loading voice engine...")
            LibVosk.setLogLevel(LogLevel.WARNINGS)
            val m = Model(paths.first)
            model = m
            val s = SpeakerModel(paths.second)
            spk = s
            val rcg = Recognizer(m, RATE.toFloat(), s)
            recognizer = rcg
            // Tiny recogniser that only knows "hey/hello/hi Jo". Much better at catching the wake word.
            val wk: Recognizer? = try {
                Recognizer(m, RATE.toFloat(), WAKE_GRAMMAR)
            } catch (e: Throwable) {
                log("Wake-word helper not available, using the normal listener.")
                null
            }
            wakeRec = wk

            val minBuf = AudioRecord.getMinBufferSize(
                RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )

            fun openMic(): AudioRecord? {
                val a = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(minBuf, RATE)
                )
                if (a.state != AudioRecord.STATE_INITIALIZED) {
                    try { a.release() } catch (ignored: Exception) {}
                    return null
                }
                a.startRecording()
                return a
            }

            var r: AudioRecord? = openMic()
            rec = r
            if (r == null) {
                log("Cannot use the microphone. Is the permission allowed?")
                return
            }

            ready = true
            state = "idle"
            if (enrolling) {
                promptEnroll()
            } else {
                log("Ready. Say \"Hey Jo\" to wake me.")
            }

            val buf = ShortArray(512)
            val ring = ArrayList<ShortArray>()
            var active = false
            var lastVoice = 0L
            var started = 0L
            var noise = 300.0
            val accText = StringBuilder()
            var accVec: DoubleArray? = null
            var accFrames = 0
            val wakeAcc = StringBuilder()
            var segAwake = false

            fun collectWake(json: String) {
                try {
                    val t = JSONObject(json).optString("text", "").trim()
                    if (t.isNotEmpty()) {
                        if (wakeAcc.isNotEmpty()) wakeAcc.append(' ')
                        wakeAcc.append(t)
                    }
                } catch (ignored: Exception) {
                }
            }

            fun collect(json: String) {
                try {
                    val o = JSONObject(json)
                    val text = o.optString("text", "").trim()
                    if (text.isEmpty()) return
                    if (accText.isNotEmpty()) accText.append(' ')
                    accText.append(text)
                    val arr = o.optJSONArray("spk")
                    val frames = o.optInt("spk_frames", 0)
                    if (arr != null && frames >= accFrames) {
                        accVec = DoubleArray(arr.length()) { arr.getDouble(it) }
                        accFrames = frames
                    }
                } catch (ignored: Exception) {
                }
            }

            fun feed(f: ShortArray, len: Int) {
                if (rcg.acceptWaveForm(f, len)) collect(rcg.result)
                if (!segAwake && wk != null) {
                    if (wk.acceptWaveForm(f, len)) collectWake(wk.result)
                }
            }

            var readErrors = 0
            while (running) {
                val cur = r
                if (cur == null) break
                val n = cur.read(buf, 0, buf.size)
                if (n < 0) {
                    // The microphone stopped giving audio (another app took it, or a glitch).
                    readErrors++
                    SystemClock.sleep(40)
                    if (readErrors >= 25) {
                        log("Microphone stopped. Reopening it...")
                        try { cur.stop() } catch (ignored: Exception) {}
                        try { cur.release() } catch (ignored: Exception) {}
                        r = openMic()
                        rec = r
                        readErrors = 0
                        if (r == null) {
                            log("Could not get the microphone back. Another app may be using it.")
                            break
                        }
                    }
                    continue
                }
                if (n == 0) continue
                readErrors = 0
                val now = SystemClock.elapsedRealtime()

                // Ignore the microphone while Jo is talking, so it does not hear itself.
                if (now < speakingUntil) {
                    if (active) {
                        rcg.reset()
                        wk?.reset()
                        wakeAcc.setLength(0)
                        accText.setLength(0)
                        accVec = null
                        accFrames = 0
                        active = false
                    }
                    ring.clear()
                    continue
                }

                val level = rms(buf, n)
                val threshold = maxOf(noise * 3.0, 450.0)
                val voiced = level > threshold
                VoiceService.level = (level / 5000.0).coerceIn(0.0, 1.0).toFloat()

                if (!active) {
                    noise = noise * 0.98 + level * 0.02
                    ring.add(buf.copyOf(n))
                    if (ring.size > 6) ring.removeAt(0)
                    if (voiced) {
                        active = true
                        lastVoice = now
                        started = now
                        segAwake = awakeNow()
                        setDot(HEAR_COLOR)
                        for (f in ring) feed(f, f.size)
                        ring.clear()
                    }
                } else {
                    feed(buf, n)
                    if (voiced) lastVoice = now
                    // Answer fast: short pause when Jo is already awake, a bit longer when it is resting.
                    val hang = if (enrolling) 900L else if (segAwake) 450L else 650L
                    if (now - lastVoice > hang || now - started > 15_000) {
                        collect(rcg.finalResult)
                        rcg.reset()
                        var wakeHit = false
                        if (!segAwake && wk != null) {
                            collectWake(wk.finalResult)
                            wk.reset()
                            wakeHit = WAKE_LOOSE.containsMatchIn(wakeAcc.toString())
                            wakeAcc.setLength(0)
                        }
                        active = false
                        setDot(IDLE_COLOR)
                        val text = accText.toString().trim()
                        val vec = accVec
                        val frames = accFrames
                        accText.setLength(0)
                        accVec = null
                        accFrames = 0
                        if (text.isNotEmpty() || wakeHit) handleUtterance(text, vec, frames, wakeHit)
                    }
                }
            }
        } catch (t: Throwable) {
            log("Voice engine error: ${t.javaClass.simpleName}: ${t.message}")
        } finally {
            val diedByItself = running
            ready = false
            if (diedByItself) {
                // The loop ended but nobody asked it to: do not stay "on" while deaf.
                state = "off"
                log("Jo stopped because the voice engine ended. Tap Start to try again.")
                main.post { stopSelf() }
            }
            try { rec?.stop() } catch (ignored: Exception) {}
            try { rec?.release() } catch (ignored: Exception) {}
            try { wakeRec?.close() } catch (ignored: Throwable) {}
            try { recognizer?.close() } catch (ignored: Throwable) {}
            try { spk?.close() } catch (ignored: Throwable) {}
            try { model?.close() } catch (ignored: Throwable) {}
        }
    }

    // ------------------------------------------------------------ what was said, and who said it

    private fun cosDist(a: DoubleArray, b: DoubleArray): Double {
        var dot = 0.0
        var na = 0.0
        var nb = 0.0
        val n = minOf(a.size, b.size)
        for (i in 0 until n) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        return 1.0 - dot / (sqrt(na) * sqrt(nb) + 1e-9)
    }

    private fun unit(v: DoubleArray): DoubleArray {
        var s = 0.0
        for (x in v) s += x * x
        val norm = sqrt(s) + 1e-9
        return DoubleArray(v.size) { v[it] / norm }
    }

    private fun handleUtterance(text: String, vec: DoubleArray?, frames: Int, wakeHit: Boolean = false) {
        if (enrolling) {
            onEnrollSample(text, vec, frames)
            return
        }

        val now = SystemClock.elapsedRealtime()
        val wake = WAKE.matchEntire(text)
        val inSession = now < sessionUntil || agent?.waiting() == true
        if (wake == null && !wakeHit && !inSession) return // resting and nobody said "Hey Jo"

        val command = when {
            wake != null -> wake.groupValues[1].trim()
            wakeHit && !inSession -> text.replace(WAKE_STRIP, "").trim()
            else -> text
        }

        // Just "Hey Jo": wake up and wait for the command.
        if (command.isEmpty()) {
            sessionUntil = now + 8_000
            beep()
            panelSay("Listening...")
            log("Awake.")
            return
        }

        var verdict = "voice check off"
        val owner = prefs.ownerVector
        if (prefs.ownerOnly && owner != null) {
            val tooShort = vec == null || (frames < MIN_VERIFY_FRAMES && text.split(" ").size < 3)
            if (tooShort) {
                if (!inSession) {
                    log("Too short to check your voice (frames $frames): $text")
                    return
                }
                verdict = "short, trusted in conversation"
            } else {
                val d = cosDist(vec!!, owner)
                val thr = prefs.threshold
                if (d > thr) {
                    log(String.format(Locale.US, "Not the owner (distance %.2f, limit %.2f): %s", d, thr, text))
                    return
                }
                verdict = String.format(Locale.US, "owner, distance %.2f", d)
            }
        }

        sessionUntil = now + 8_000
        log("You ($verdict): $text")
        panelSay("\u201C" + command + "\u201D")
        main.post {
            // Show the panel first: starting an app from the background is allowed while a window is up.
            if (panel == null) showPanel()
            state = "thinking"
            main.postDelayed({ if (state == "thinking") state = if (awakeNow()) "awake" else "idle" }, 1500)
            agent?.handle(command)
        }
    }

    // ------------------------------------------------------------ teaching Jo your voice

    private fun beginEnroll() {
        enrolling = true
        enrollVecs.clear()
        if (ready) promptEnroll()
        else log("Getting ready to learn your voice...")
    }

    private fun promptEnroll() {
        val i = enrollVecs.size
        val phrase = ENROLL_PHRASES[i]
        log("Sentence ${i + 1} of ${ENROLL_PHRASES.size}, read aloud: \"$phrase\"")
        speak("Sentence ${i + 1}. Please say: $phrase")
    }

    private fun onEnrollSample(text: String, vec: DoubleArray?, frames: Int) {
        val words = text.split(" ").size
        if (vec == null || (frames < MIN_ENROLL_FRAMES && words < 4)) {
            log("That was too short (frames $frames). Heard: $text")
            speak("Please say the whole sentence.")
            return
        }
        enrollVecs.add(unit(vec))
        log("Sample ${enrollVecs.size} of ${ENROLL_PHRASES.size} saved (frames $frames).")
        if (enrollVecs.size < ENROLL_PHRASES.size) {
            promptEnroll()
            return
        }

        val dim = enrollVecs[0].size
        val mean = DoubleArray(dim)
        for (v in enrollVecs) {
            for (i in 0 until dim) mean[i] += v[i] / enrollVecs.size
        }
        var maxD = 0.0
        for (v in enrollVecs) maxD = maxOf(maxD, cosDist(v, mean))
        val thr = (maxD * 2.0 + 0.15).coerceIn(0.35, 0.70).toFloat()

        prefs.ownerVector = mean
        prefs.baseThreshold = thr
        prefs.strictness = 0
        prefs.ownerOnly = true
        enrolling = false
        enrollVecs.clear()
        log(String.format(Locale.US, "Voice saved. Spread %.2f, limit %.2f.", maxD, thr))
        speak("Done. From now on I only obey your voice.")
    }
}
