package com.jp.voiceassistant

import java.util.Locale

/** One AI service Jo can use as its brain. */
data class Provider(
    val id: String,
    val name: String,
    val url: String,
    val model: String,
    val keyUrl: String,
    val note: String,
    val anthropic: Boolean = false
)

/** Free (and one paid) AI services. Model names change often, so the model is editable in the app. */
object Providers {
    val all: List<Provider> = listOf(
        Provider(
            "gemini", "Google Gemini",
            "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions",
            "gemini-flash-latest", "https://aistudio.google.com/apikey",
            "Free, no card. Google may use free-tier prompts."
        ),
        Provider(
            "groq", "Groq",
            "https://api.groq.com/openai/v1/chat/completions",
            "llama-3.3-70b-versatile", "https://console.groq.com/keys",
            "Free, no card. Very fast."
        ),
        Provider(
            "openrouter", "OpenRouter",
            "https://openrouter.ai/api/v1/chat/completions",
            "meta-llama/llama-3.3-70b-instruct:free", "https://openrouter.ai/keys",
            "Free models, no card. Small daily limit."
        ),
        Provider(
            "cerebras", "Cerebras",
            "https://api.cerebras.ai/v1/chat/completions",
            "llama-3.3-70b", "https://cloud.cerebras.ai",
            "Free, no card. Fast."
        ),
        Provider(
            "mistral", "Mistral",
            "https://api.mistral.ai/v1/chat/completions",
            "mistral-small-latest", "https://console.mistral.ai/api-keys",
            "Free plan. Prompts may be used for training."
        ),
        Provider(
            "github", "GitHub Models",
            "https://models.github.ai/inference/chat/completions",
            "openai/gpt-4.1-mini", "https://github.com/settings/personal-access-tokens",
            "Free with a GitHub account. Token needs Models permission."
        ),
        Provider(
            "anthropic", "Claude (paid)",
            "https://api.anthropic.com/v1/messages",
            "claude-haiku-5-5", "https://console.anthropic.com/settings/keys",
            "Paid. Best at following instructions.", true
        ),
        Provider(
            "custom", "Custom",
            "", "", "",
            "Any OpenAI-style https endpoint."
        )
    )

    fun byId(id: String): Provider = all.firstOrNull { it.id == id } ?: all[0]

    /** Only https, no spaces, sane length. Keys are never sent over plain http. */
    fun isSafeUrl(u: String): Boolean =
        u.startsWith("https://") && u.length in 12..300 && !u.contains(' ') && !u.contains('\n')
}

/** Allows at most [perMinute] calls a minute and [minGapMs] between calls. */
class RateLimiter(private val perMinute: Int, private val minGapMs: Long) {
    private val stamps = ArrayList<Long>()

    @Synchronized
    fun allow(now: Long): Boolean {
        while (stamps.isNotEmpty() && now - stamps[0] > 60_000L) stamps.removeAt(0)
        if (stamps.size >= perMinute) return false
        if (stamps.isNotEmpty() && now - stamps[stamps.size - 1] < minGapMs) return false
        stamps.add(now)
        return true
    }
}

/** Stops calling the brain for a while after repeated failures. */
class Breaker(private val maxFails: Int, private val pauseMs: Long) {
    private var fails = 0
    private var until = 0L

    @Synchronized
    fun open(now: Long): Boolean = now < until

    @Synchronized
    fun success() {
        fails = 0
    }

    @Synchronized
    fun failure(now: Long) {
        fails++
        if (fails >= maxFails) {
            until = now + pauseMs
            fails = 0
        }
    }
}

/** The brain may only suggest ordinary voice commands. These filters keep it from doing risky things on its own. */
object Guard {
    private val NO_SCREEN = Regex("^(?:type|write|enter|dictate|tap|click|press|hit|select)\\b")
    private val NO_POWER = Regex("^(?:exit|shut ?down|stop listening|turn off listening|go to sleep)\\b")
    private val NO_CONFIRM = Regex(
        "^(?:ok |okay )?(?:send|send it|send now|send message|yes|yeah|yep|yup|sure|confirm|go ahead|do it|correct|right|that one)$"
    )

    fun cleanCommands(raw: List<String>): List<String> {
        val out = ArrayList<String>()
        for (c0 in raw) {
            val c = c0.lowercase(Locale.ROOT)
                .replace(Regex("[^\\p{L}\\p{N}' ]"), " ")
                .replace(Regex("\\s+"), " ")
                .trim()
            if (c.isEmpty() || c.length > 160) continue
            if (NO_SCREEN.containsMatchIn(c) || NO_POWER.containsMatchIn(c) || NO_CONFIRM.matches(c)) continue
            out.add(c)
            if (out.size >= 4) break
        }
        return out
    }

    /** Removes anything that looks like a key from text before it is logged or shown. */
    fun scrub(text: String, key: String): String {
        var s = text
        if (key.length >= 8) s = s.replace(key, "***")
        return s.replace(Regex("(?i)(bearer\\s+|key[=: ]+)[A-Za-z0-9_\\-\\.]{12,}"), "$1***").take(240)
    }
}
