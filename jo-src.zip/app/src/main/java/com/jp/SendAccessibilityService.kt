package com.jp.voiceassistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Jo's hands: presses buttons, types text, scrolls and does Home/Back in any app.
 * It only acts when Jo calls one of these functions after you ask.
 */
class SendAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: SendAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    // ---- system buttons
    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun recents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun screenshot(): Boolean = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)

    // ---- tapping
    private fun clickNode(node: AccessibilityNodeInfo?): Boolean {
        var n = node
        var hops = 0
        while (n != null && !n.isClickable && hops < 6) {
            n = n.parent
            hops++
        }
        return n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    /** Presses the Send button (WhatsApp and most chat apps). */
    fun clickSend(): Boolean {
        val root = rootInActiveWindow ?: return false
        val pkg = root.packageName?.toString().orEmpty()
        if (pkg.isNotEmpty()) {
            val byId = root.findAccessibilityNodeInfosByViewId("$pkg:id/send")
            if (byId != null && byId.isNotEmpty() && clickNode(byId[0])) return true
        }
        return tapText("send")
    }

    /** Taps the first thing on screen whose text or description contains [label]. */
    fun tapText(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(label) ?: return false
        for (n in nodes) {
            if (clickNode(n)) return true
        }
        return false
    }

    // ---- typing
    private fun findEditable(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = java.util.ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.poll() ?: break
            if (n.isEditable) return n
            for (i in 0 until n.childCount) {
                n.getChild(i)?.let { queue.add(it) }
            }
        }
        return null
    }

    /** Types [text] into the focused text box (or the first one on screen). */
    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val old = if (node.isShowingHintText) "" else node.text?.toString().orEmpty()
        val args = Bundle()
        args.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
            if (old.isEmpty()) text else "$old $text"
        )
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // ---- scrolling
    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow ?: return false
        val queue = java.util.ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        while (queue.isNotEmpty()) {
            val n = queue.poll() ?: break
            if (n.isScrollable) {
                return n.performAction(
                    if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                )
            }
            for (i in 0 until n.childCount) {
                n.getChild(i)?.let { queue.add(it) }
            }
        }
        return false
    }
}
