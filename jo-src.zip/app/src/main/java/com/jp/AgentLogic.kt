package com.jp.voiceassistant

import java.util.Locale

/** How careful Jo must be before tapping something. */
enum class Sens { NONE, SEND, MONEY }

/**
 * Safety rules for the screen agent. Pure Kotlin so they can be unit tested.
 * The model proposes; these rules decide what is allowed.
 */
object AgentLogic {

    // Things that move money or destroy data: always need a spoken yes.
    private val MONEY = Regex(
        "\\b(?:pay|pay now|payment|buy|buy now|purchase|place order|order now|checkout|check out|transfer|send money|" +
            "donate|subscribe|upgrade|delete|erase|remove account|uninstall|factory reset|reset phone|sign out|log out|logout)\\b"
    )

    // Things that publish or send something to other people: spoken yes unless "send automatically" is on.
    private val SEND = Regex("\\b(?:send|post|share|publish|tweet|submit|go live)\\b")

    // Apps Jo will never operate: payments, banking, password managers, authenticators, Jo itself.
    private val BLOCKED_PKG = Regex(
        "(?:paisa|phonepe|paytm|npci|bhim|upi|bank|wallet|razorpay|gpay|googlepay|walletnfcrel|" +
            "authenticator|keepass|bitwarden|lastpass|1password|dashlane|nordpass|" +
            "com\\.jp\\.voiceassistant|com\\.android\\.vending|com\\.google\\.android\\.apps\\.walletnfcrel)"
    )

    fun sensitivity(label: String): Sens {
        val l = label.lowercase(Locale.ROOT)
        if (MONEY.containsMatchIn(l)) return Sens.MONEY
        if (SEND.containsMatchIn(l)) return Sens.SEND
        return Sens.NONE
    }

    fun blockedPackage(pkg: String): Boolean = BLOCKED_PKG.containsMatchIn(pkg.lowercase(Locale.ROOT))

    /** One line of text safe to put in a prompt: no line breaks, limited length. */
    fun clip(s: String, max: Int): String {
        val one = s.replace(Regex("\\s+"), " ").trim()
        return if (one.length <= max) one else one.substring(0, max - 1) + "…"
    }

    /** Detects an agent that keeps repeating itself. */
    class LoopGuard(private val window: Int = 4, private val limit: Int = 3) {
        private val recent = ArrayList<String>()

        /** Returns true when the same step has now been tried [limit] times in the last [window] steps. */
        fun stuck(signature: String): Boolean {
            recent.add(signature)
            while (recent.size > window) recent.removeAt(0)
            return recent.count { it == signature } >= limit
        }
    }
}
