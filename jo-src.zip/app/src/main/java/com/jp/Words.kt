package com.jp.voiceassistant

/**
 * Turns spoken numbers, durations and clock times into values.
 * Pure Kotlin on purpose (no Android imports) so it can be unit tested on a laptop.
 * Input is expected to be lowercase text with punctuation already removed.
 */
object Words {

    private val ONES = mapOf(
        "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5,
        "six" to 6, "seven" to 7, "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11,
        "twelve" to 12, "thirteen" to 13, "fourteen" to 14, "fifteen" to 15, "sixteen" to 16,
        "seventeen" to 17, "eighteen" to 18, "nineteen" to 19
    )
    private val TENS = mapOf(
        "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50,
        "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
    )

    /** "set timer for twenty five minutes" -> "set timer for 25 minutes" */
    fun digits(text: String): String {
        val w = text.split(" ").filter { it.isNotEmpty() }
        val out = ArrayList<String>()
        var i = 0
        while (i < w.size) {
            // "six oh five" -> "6 05"
            if ((w[i] == "oh" || w[i] == "o") && i + 1 < w.size && out.isNotEmpty() &&
                out.last().all { it.isDigit() }
            ) {
                val o = ONES[w[i + 1]]
                if (o != null && o in 1..9) {
                    out.add("0$o")
                    i += 2
                    continue
                }
            }
            val r = readNumber(w, i)
            if (r != null) {
                out.add(r.first.toString())
                i = r.second
            } else {
                out.add(w[i])
                i++
            }
        }
        return out.joinToString(" ")
    }

    private fun readNumber(w: List<String>, start: Int): Pair<Int, Int>? {
        var i = start
        var total = 0
        var got = false
        val first = ONES[w[i]]
        if (first != null && first in 1..9 && i + 1 < w.size && w[i + 1] == "hundred") {
            total = first * 100
            i += 2
            got = true
            if (i + 1 < w.size && w[i] == "and" && (ONES.containsKey(w[i + 1]) || TENS.containsKey(w[i + 1]))) i++
        }
        val rest = readUnder100(w, i)
        if (rest != null) {
            total += rest.first
            i = rest.second
            got = true
        }
        return if (got) Pair(total, i) else null
    }

    private fun readUnder100(w: List<String>, i: Int): Pair<Int, Int>? {
        if (i >= w.size) return null
        val t = TENS[w[i]]
        if (t != null) {
            if (i + 1 < w.size) {
                val o = ONES[w[i + 1]]
                if (o != null && o in 1..9) return Pair(t + o, i + 2)
            }
            return Pair(t, i + 1)
        }
        val o = ONES[w[i]]
        if (o != null) return Pair(o, i + 1)
        return null
    }

    // ------------------------------------------------------------ durations

    private fun unitSeconds(u: String): Int = when {
        u.startsWith("h") -> 3600
        u.startsWith("m") -> 60
        else -> 1
    }

    private fun amount(g: String): Int = g.toIntOrNull() ?: 1

    private val UNIT = "(hours?|hrs?|minutes?|mins?|seconds?|secs?)"
    private val RE_N_AND_HALF = Regex("(\\d+|\\ban?\\b) and a half $UNIT\\b")
    private val RE_AN_UNIT_AND_HALF = Regex("\\ban? (hour|minute) and a half\\b")
    private val RE_HALF_HOUR = Regex("\\bhalf an? hour\\b|\\bhalf hour\\b")
    private val RE_QUARTER_HOUR = Regex("\\ba quarter of an hour\\b|\\bquarter of an hour\\b|\\bquarter hour\\b")
    private val RE_AMOUNT = Regex("(\\d+|\\ban?\\b)\\s*$UNIT\\b")

    /** "ten minutes" -> 600, "1 hour 30 minutes" -> 5400, "half an hour" -> 1800. Null if no duration is found. */
    fun durationSeconds(raw: String): Int? {
        var s = digits(raw)
        var total = 0
        var found = false

        RE_N_AND_HALF.find(s)?.let { m ->
            val u = unitSeconds(m.groupValues[2])
            total += amount(m.groupValues[1]) * u + u / 2
            found = true
            s = s.replace(m.value, " ")
        }
        RE_AN_UNIT_AND_HALF.find(s)?.let { m ->
            val u = unitSeconds(m.groupValues[1])
            total += u + u / 2
            found = true
            s = s.replace(m.value, " ")
        }
        if (RE_HALF_HOUR.containsMatchIn(s)) {
            total += 1800
            found = true
            s = s.replace(RE_HALF_HOUR, " ")
        }
        if (RE_QUARTER_HOUR.containsMatchIn(s)) {
            total += 900
            found = true
            s = s.replace(RE_QUARTER_HOUR, " ")
        }
        for (m in RE_AMOUNT.findAll(s)) {
            total += amount(m.groupValues[1]) * unitSeconds(m.groupValues[2])
            found = true
        }
        return if (found && total > 0) total else null
    }

    /** 5400 -> "1 hour 30 minutes", 45 -> "45 seconds" */
    fun spokenDuration(sec: Int): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add(if (h == 1) "1 hour" else "$h hours")
        if (m > 0) parts.add(if (m == 1) "1 minute" else "$m minutes")
        if (s > 0) parts.add(if (s == 1) "1 second" else "$s seconds")
        return parts.joinToString(" ")
    }

    // ------------------------------------------------------------ clock times

    /**
     * hour/minute as spoken. explicit = the speaker made the hour unambiguous (am/pm, "18 30", noon).
     * When explicit, hour is 0..23. When not, hour is 1..12 and the caller picks am or pm with [resolve].
     */
    data class Clock(val hour: Int, val minute: Int, val explicit: Boolean)

    private val RE_HALF_PAST = Regex("\\bhalf past (\\d{1,2})\\b")
    private val RE_QUARTER_PAST = Regex("\\bquarter past (\\d{1,2})\\b")
    private val RE_QUARTER_TO = Regex("\\bquarter to (\\d{1,2})\\b")
    private val RE_OCLOCK = Regex("\\b(\\d{1,2}) ?o ?clock\\b")
    private val RE_HM = Regex("\\b(\\d{1,2}) (\\d{2})\\b")
    private val RE_H_MER = Regex("\\b(\\d{1,2}) ?(?:am|pm)\\b")
    private val RE_BARE = Regex("\\b(\\d{1,2})\\b")

    /** "six thirty a m" -> Clock(6, 30, true). Null if no time is found. */
    fun clock(raw: String): Clock? {
        var s = digits(raw)
        s = s.replace(Regex("\\ba m\\b"), "am").replace(Regex("\\bp m\\b"), "pm")
        if (Regex("\\bnoon\\b").containsMatchIn(s)) return Clock(12, 0, true)
        if (Regex("\\bmidnight\\b").containsMatchIn(s)) return Clock(0, 0, true)

        val am = Regex("\\bam\\b|\\bmorning\\b").containsMatchIn(s)
        val pm = Regex("\\bpm\\b|\\bafternoon\\b|\\bevening\\b|\\btonight\\b|\\bnight\\b").containsMatchIn(s)
        val mer = am || pm

        var h: Int
        var min: Int
        var back = 0 // minutes to step back (for "quarter to")
        val hp = RE_HALF_PAST.find(s)
        val qp = RE_QUARTER_PAST.find(s)
        val qt = RE_QUARTER_TO.find(s)
        val oc = RE_OCLOCK.find(s)
        val hm = RE_HM.find(s)
        val hmer = RE_H_MER.find(s)
        val bare = RE_BARE.find(s)
        when {
            hp != null -> { h = hp.groupValues[1].toInt(); min = 30 }
            qp != null -> { h = qp.groupValues[1].toInt(); min = 15 }
            qt != null -> { h = qt.groupValues[1].toInt(); min = 0; back = 15 }
            oc != null -> { h = oc.groupValues[1].toInt(); min = 0 }
            hm != null && hm.groupValues[2].toInt() < 60 -> { h = hm.groupValues[1].toInt(); min = hm.groupValues[2].toInt() }
            hmer != null -> { h = hmer.groupValues[1].toInt(); min = 0 }
            bare != null -> { h = bare.groupValues[1].toInt(); min = 0 }
            else -> return null
        }

        var explicit: Boolean
        if (mer) {
            if (h < 1 || h > 12) return null
            h %= 12
            if (pm && !am) h += 12
            explicit = true
        } else if (h == 0 || h > 12) {
            if (h > 23) return null
            explicit = true // "18 30" or "0 15" is a 24 hour reading
        } else {
            explicit = false
        }
        if (min !in 0..59) return null

        if (back > 0) {
            // quarter to H = (H - 1):45
            if (explicit) h = (h + 23) % 24 else h = if (h == 1) 12 else h - 1
            min = 60 - back
        }
        return Clock(h, min, explicit)
    }

    /** Picks am or pm for a clock reading without one: whichever happens next after now. Returns hour 0..23 and minute. */
    fun resolve(c: Clock, nowHour: Int, nowMinute: Int): Pair<Int, Int> {
        if (c.explicit) return Pair(c.hour % 24, c.minute)
        val base = c.hour % 12
        val nowMin = nowHour * 60 + nowMinute
        var best = base
        var bestWait = Int.MAX_VALUE
        for (cand in listOf(base, base + 12)) {
            val t = cand * 60 + c.minute
            val wait = ((t - nowMin - 1 + 1440) % 1440) + 1
            if (wait < bestWait) {
                bestWait = wait
                best = cand
            }
        }
        return Pair(best, c.minute)
    }

    /** 18, 5 -> "6:05 PM" */
    fun spokenClock(hour: Int, minute: Int): String {
        val h12 = if (hour % 12 == 0) 12 else hour % 12
        val suffix = if (hour < 12) "AM" else "PM"
        return "$h12:" + (if (minute < 10) "0$minute" else "$minute") + " $suffix"
    }

    // ------------------------------------------------------------ reminders

    /** what to be reminded about, and when: either in [seconds] from now or at [clock]. Both null = no time heard. */
    data class Reminder(val what: String, val seconds: Int?, val clock: Clock?)

    private val RE_REMIND = Regex("^remind me (?:to |about |that )?(.+)$")
    private val RE_REMIND_IN_FIRST = Regex("^in (.+?) (?:to|about|that) (.+)$")
    private val RE_MARKER = Regex(" (at|by|in) ")

    /** "remind me to call mom at six thirty p m" -> Reminder("call mom", null, Clock(18,30,true)) */
    fun reminder(raw: String): Reminder? {
        val body = RE_REMIND.matchEntire(raw.trim())?.groupValues?.get(1) ?: return null

        RE_REMIND_IN_FIRST.matchEntire(body)?.let { m ->
            val sec = durationSeconds(m.groupValues[1])
            if (sec != null) return Reminder(m.groupValues[2].trim(), sec, null)
        }

        val markers = RE_MARKER.findAll(body).toList().reversed()
        for (m in markers) {
            val what = body.substring(0, m.range.first).trim()
            val whenText = body.substring(m.range.last + 1)
            if (what.isEmpty()) continue
            if (m.groupValues[1] == "in") {
                val sec = durationSeconds(whenText)
                if (sec != null) return Reminder(what, sec, null)
            } else {
                val c = clock(whenText)
                if (c != null) return Reminder(what, null, c)
            }
        }
        return Reminder(body.trim(), null, null)
    }
}
