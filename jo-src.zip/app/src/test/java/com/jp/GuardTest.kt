package com.jp.voiceassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class GuardTest {

    @Test fun blocksRiskyCommands() {
        val out = Guard.cleanCommands(
            listOf("Open WhatsApp", "send", "yes", "tap Pay now", "type my password", "stop listening", "Text Prem I'm late")
        )
        assertEquals(listOf("open whatsapp", "text prem i'm late"), out)
    }

    @Test fun capsCommandCount() {
        val out = Guard.cleanCommands(List(10) { "open app $it" })
        assertEquals(4, out.size)
    }

    @Test fun scrubHidesKey() {
        val s = Guard.scrub("bad key sk-abcdef1234567890 here", "sk-abcdef1234567890")
        assertFalse(s.contains("abcdef1234"))
    }

    @Test fun rateLimiter() {
        val r = RateLimiter(2, 1000)
        assertTrue(r.allow(0))
        assertFalse(r.allow(500))
        assertTrue(r.allow(1500))
        assertFalse(r.allow(3000))
        assertTrue(r.allow(70_000))
    }

    @Test fun breaker() {
        val b = Breaker(2, 60_000)
        b.failure(0)
        assertFalse(b.open(1))
        b.failure(2)
        assertTrue(b.open(3))
        assertFalse(b.open(61_000))
    }

    @Test fun safeUrl() {
        assertTrue(Providers.isSafeUrl("https://api.groq.com/openai/v1/chat/completions"))
        assertFalse(Providers.isSafeUrl("http://example.com/v1"))
    }
}
