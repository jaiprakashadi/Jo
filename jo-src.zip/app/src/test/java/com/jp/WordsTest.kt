package com.jp.voiceassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class WordsTest {

    @Test fun numberWords() {
        assertEquals("set timer for 25 minutes", Words.digits("set timer for twenty five minutes"))
        assertEquals("105", Words.digits("one hundred and five"))
        assertEquals("250", Words.digits("two hundred fifty"))
        assertEquals("6 30", Words.digits("six thirty"))
        assertEquals("6 05", Words.digits("six oh five"))
    }

    @Test fun durations() {
        assertEquals(600, Words.durationSeconds("set a timer for ten minutes"))
        assertEquals(5400, Words.durationSeconds("one hour thirty minutes"))
        assertEquals(5400, Words.durationSeconds("an hour and a half"))
        assertEquals(5400, Words.durationSeconds("one and a half hours"))
        assertEquals(1800, Words.durationSeconds("half an hour"))
        assertEquals(90, Words.durationSeconds("ninety seconds"))
        assertEquals(60, Words.durationSeconds("a minute"))
        assertNull(Words.durationSeconds("hello there"))
    }

    @Test fun spokenDurations() {
        assertEquals("1 hour 30 minutes", Words.spokenDuration(5400))
        assertEquals("45 seconds", Words.spokenDuration(45))
        assertEquals("10 minutes", Words.spokenDuration(600))
    }

    @Test fun clockTimes() {
        assertEquals(Words.Clock(6, 30, true), Words.clock("six thirty a m"))
        assertEquals(Words.Clock(18, 0, true), Words.clock("six pm"))
        assertEquals(Words.Clock(18, 5, true), Words.clock("six oh five p m"))
        assertEquals(Words.Clock(0, 30, true), Words.clock("twelve thirty a m"))
        assertEquals(Words.Clock(6, 30, false), Words.clock("half past six"))
        assertEquals(Words.Clock(6, 45, false), Words.clock("quarter to seven"))
        assertEquals(Words.Clock(12, 45, false), Words.clock("quarter to one"))
        assertEquals(Words.Clock(12, 0, true), Words.clock("noon"))
        assertEquals(Words.Clock(18, 30, true), Words.clock("eighteen thirty"))
        assertEquals(Words.Clock(7, 0, false), Words.clock("seven"))
        assertNull(Words.clock("hello"))
    }

    @Test fun pickAmOrPm() {
        assertEquals(Pair(6, 30), Words.resolve(Words.Clock(6, 30, false), 19, 0))
        assertEquals(Pair(6, 30), Words.resolve(Words.Clock(6, 30, false), 5, 0))
        assertEquals(Pair(18, 30), Words.resolve(Words.Clock(6, 30, false), 10, 0))
        assertEquals(Pair(18, 0), Words.resolve(Words.Clock(18, 0, true), 10, 0))
    }

    @Test fun spokenClocks() {
        assertEquals("6:05 PM", Words.spokenClock(18, 5))
        assertEquals("12:30 AM", Words.spokenClock(0, 30))
        assertEquals("12:00 PM", Words.spokenClock(12, 0))
    }

    @Test fun reminders() {
        assertEquals(
            Words.Reminder("call mom", null, Words.Clock(18, 30, true)),
            Words.reminder("remind me to call mom at six thirty p m")
        )
        assertEquals(
            Words.Reminder("drink water", 600, null),
            Words.reminder("remind me in ten minutes to drink water")
        )
        assertEquals(
            Words.Reminder("call mom", 600, null),
            Words.reminder("remind me to call mom in ten minutes")
        )
        assertEquals(Words.Reminder("buy milk", null, null), Words.reminder("remind me to buy milk"))
        assertNull(Words.reminder("what time is it"))
    }
}
