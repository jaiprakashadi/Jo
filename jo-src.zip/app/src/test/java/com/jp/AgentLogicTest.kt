package com.jp.voiceassistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentLogicTest {

    @Test fun sensitivity() {
        assertEquals(Sens.SEND, AgentLogic.sensitivity("Send"))
        assertEquals(Sens.SEND, AgentLogic.sensitivity("Share to story"))
        assertEquals(Sens.MONEY, AgentLogic.sensitivity("Pay now"))
        assertEquals(Sens.MONEY, AgentLogic.sensitivity("Delete chat"))
        assertEquals(Sens.NONE, AgentLogic.sensitivity("Search"))
        assertEquals(Sens.NONE, AgentLogic.sensitivity("Sticker"))
    }

    @Test fun blockedPackages() {
        assertTrue(AgentLogic.blockedPackage("com.phonepe.app"))
        assertTrue(AgentLogic.blockedPackage("com.sbi.bank.app"))
        assertTrue(AgentLogic.blockedPackage("com.jp.voiceassistant"))
        assertFalse(AgentLogic.blockedPackage("com.instagram.android"))
        assertFalse(AgentLogic.blockedPackage("com.picsart.studio"))
    }

    @Test fun clip() {
        assertEquals("a b", AgentLogic.clip("  a\n b ", 10))
        assertEquals(5, AgentLogic.clip("abcdefghij", 5).length)
    }

    @Test fun loopGuard() {
        val g = AgentLogic.LoopGuard()
        assertFalse(g.stuck("tap 3"))
        assertFalse(g.stuck("tap 3"))
        assertTrue(g.stuck("tap 3"))
    }
}
