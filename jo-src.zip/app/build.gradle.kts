plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jp.voiceassistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jp.voiceassistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "2.4"

        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    signingConfigs {
        create("jo") {
            storeFile = file("jo.keystore")
            storePassword = "android"
            keyAlias = "jo"
            keyPassword = "android"
            storeType = "pkcs12"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("jo")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    testImplementation("junit:junit:4.13.2")

    // Offline speech recognition + voiceprint (speaker) model
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    implementation("com.alphacephei:vosk-android:0.3.32+") {
        exclude(group = "net.java.dev.jna", module = "jna")
    }
}
